import React, { useState, useEffect } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import './css/styles1.css';
const MillerComponent = () => {
  const [farmers, setFarmers] = useState([]);
  const [name, setName] = useState("");
  const [fname,setFname] = useState("");
  const [grains, setGrains] = useState(0);

  useEffect(() => {
    const loggedInName = localStorage.getItem("name");
    const loggedInRole = localStorage.getItem("role");
    const loggedInAadhar = localStorage.getItem("aadhar");
    const loggedInLocation = localStorage.getItem("location");

    if (loggedInName) {
      setName(loggedInName);
    }
  }, []);

  const fetchFarmers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-farmers');
      setFarmers(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchFarmers();
  }, []);



  const handleDeductGrains = (e) => {
    e.preventDefault();

    axios.post('http://localhost:3001/deduct-grains-farmer', { fname, name ,  grains })
      .then(response => {
        console.log(response);
        fetchFarmers();
      })
      .catch(error => {
        console.log(error);
      });
    setFname("");
    setGrains("");
  };
  const handleReadyToSell = () => {
    axios.put('http://localhost:3001/miller-ready' , {
      name: name
    })
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.error(error);
    });
  };
  const handleNotReadyToSell = () => {
    axios.put('http://localhost:3001/miller-not-ready' , {
      name: name
    })
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.error(error);
    });
  };

  const handleShowGrains = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-grains-miller' ,{
        params: {
          name: name
        }
      });
      const farmerGrains = response.data.grains;
      setGrains(farmerGrains);
    } catch (error) {
      console.error(error);
    }
  };



  return (
    <div>
    <div class="container">
    <a href="/Login" class="back-button" >&larr;</a>
    <header>
      <h1>
          MILLER COMPONENT
      </h1>
    </header>
    <h1 class="text-center">Welcome {name}</h1>
    <form class="registration-form">
      {/* <label class="col-one-half">
        <span class="label-text">Name</span>
        <input type="text" name="firstName" value={name}
            onChange={(e) => setName(e.target.value)}
            required/>
      </label> */}      
      <div class="text-center">
        {/* <button class="submit" name="register" onClick={fetchFarmers}> SHOW ALL FARMERS </button> */}
        <button class="submit"><NavLink to="/Millertable">SHOW ALL FARMERS</NavLink></button>
      </div>
      <br/>
      <label class="col-one-half">
        <span class="label-text">Name</span>
        <input type="text" name="firstName"  value={fname}
            onChange={(e) => setFname(e.target.value)}
            required/>
      </label>
      <label class="col-one-half">
        <span class="label-text">Grains to deduct</span>
        <input type="number" name="firstName" value={grains}
            onChange={(e) => setGrains(e.target.value)}
            required
/>
      </label>
      <div class="text-center">
        <button class="submit" name="register" onClick={handleDeductGrains}> DEDUCT GRAINS</button>
        <br/>
        <br/>
        <button class="submit" name="register" onClick={handleReadyToSell}>READY TO SELL</button>
        <button class="submit" name="register" onClick={handleShowGrains}> SHOW GRAINS </button>
        <button class="submit" name="register" onClick={handleNotReadyToSell}> REMOVE FROM LISTING </button>
      </div>
      <br/>
      
    </form>
  </div>
  </div>
  );
};

export default MillerComponent;
