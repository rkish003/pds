import React, { useState, useEffect } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import './css/styles1.css';

const FciComponent = () => {
  const [millers, setMillers] = useState([]);
  const [fps,setfps]=useState([]);
  const [name, setName] = useState("");
  const [mname, setMname] = useState("");
  const [fpname, setFpname] = useState("");
  const [mgrains, setMgrains] = useState(0);
  const [fpgrains, setFpgrains] = useState(0);
  const [grains, setGrains] = useState(0);

  useEffect(() => {
    const loggedInName = localStorage.getItem("name");
    const loggedInRole = localStorage.getItem("role");
    const loggedInAadhar = localStorage.getItem("aadhar");
    const loggedInLocation = localStorage.getItem("location");

    if (loggedInName) {
      setName(loggedInName);
    }
  }, []);

  const fetchMillers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-millers');
      setMillers(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchMillers();
  }, []);

  const handleDeductGrains = (e) => {
    e.preventDefault();
    console.log("going to hiandle : " + mgrains);
    axios.post('http://localhost:3001/deduct-grains-Miller', {
      mname: mname,
      name: name,
      mgrains: mgrains 
    })
      .then(response => {
        console.log(response);
        fetchMillers();
      })
      .catch(error => {
        console.log(error);
      });

    setMname("");
  };

  const handleShowGrains = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-grains-FCI');
      const farmerGrains = response.data.grains;
      setGrains(farmerGrains);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchfps = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-fps');
      setfps(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchfps();
  }, []);

  const handleAcceptRequest = async () => {
    try {
      const response = await axios.post('http://localhost:3001/fci-accept-request', {
        fpname:fpname,
        name:name,
        fpgrains:fpgrains
      });
      console.log(response.data);
    } catch (error) {
      console.error('Error accepting request:', error);
    }
  };

  const handleDenyRequest = async () => {
    try {
      const response = await axios.post('http://localhost:3001/fci-deny-request', { fpname:fpname });
      console.log(response.data);
    } catch (error) {
      console.error('Error denying request:', error);
    }
  };

  return (
    <div>
    <div class="container">
    <a href="/Login" class="back-button" >&larr;</a>
    <header>
      <h1>
         FCI 
      </h1>
    </header>
    <h1 class="text-center">WELCOME {name}</h1>
    <div class="text-center">
    <button ><NavLink to="/Fcitable">SHOW ALL MILLERS</NavLink></button>
    </div>
    <br/><br/>
    <form class="registration-form">
    
      <label class="col-one-half">
        <span class="label-text">Name</span>
        <input type="text" name="firstName" value={mname}
            onChange={(e) => setMname(e.target.value)}
            required/>
      </label>
      <label class="col-one-half">
        <span class="label-text">Grains to Deduct</span>
        <input type="number" name="firstName"value={mgrains}
            onChange={(e) => setMgrains(e.target.value)}
            required/>
      </label>
      
      <div class="text-center">
        <button class="submit" name="register" onClick={handleDeductGrains} > DEDUCT </button>
        <button class="submit" name="register" onClick={handleShowGrains}> SHOW </button>
      </div>
      <br/>
      <label class="col-one-half">
        <span class="label-text">Name</span>
        <input type="text" name="firstName" id="name"
            value={fpname}
            onChange={(e) => setFpname(e.target.value)}/>
      </label>
      <label class="col-one-half">
        <span class="label-text">Grains to Accept</span>
        <input type="number" name="firstName"id="grains"
            value={fpgrains}
            onChange={(e) => setFpgrains(e.target.value)}/>
      </label>
      <div class="text-center">
        <button class="submit" name="register" onClick={handleAcceptRequest}> ACCEPT</button>
        <button class="submit" name="register" onClick={handleDenyRequest}> DENY </button>
      </div>
      <br/>
      <div class="text-center">
        {/* <button class="submit" name="register" onClick={fetchMillers}> SHOW ALL MILLERS </button> */}
        <button><NavLink to="/Fpstable">SHOW ALL FPS</NavLink></button>
        {/* <button class="submit" name="register" onClick={fetchfps}> SHOW ALL FPS </button> */}
        
      </div>
      <br/>
      
    </form>
  </div>
  </div>
  );
};

export default FciComponent;
