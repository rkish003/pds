import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { NavLink } from "react-router-dom";
import './css/styles1.css';
function Login() {
  const [isVisible,setIsVisible] = useState(false);

  const [role,setRole] = useState("");
    function handleVisibility(e) {
      setRole(e.target.value);
      console.log(role);
      var currRole = e.target.value;
      if( currRole === "Fci" || currRole === "") {
        setIsVisible(false);
      }
      else {
        setIsVisible(true);
      }
      // <NavLink to=data ></NavLink>
    }

    function handleLogin(e) {
      e.preventDefault();
      var data;
      if(e.target.role.value === "Fci") {
        data = {
          role: e.target.role.value,
          password: e.target.pwd.value
        }
      }
      else {
        data = {
          role: e.target.role.value,
          aadhar: e.target.aadhar.value,
          password: e.target.pwd.value
        }
      }
      console.log(data);
      axios.post('http://localhost:3001/login', { data })
          .then(response => {
            console.log("login success");
            console.log(data.name);
            localStorage.setItem('name',response.data.name);
            localStorage.setItem('role',response.data.role);
            localStorage.setItem('aadhar',response.data.aadhar);
            localStorage.setItem('location',response.data.location);
            window.location.replace('/'+response.data.role);
            console.log("res = "+ JSON.stringify(response.data));

          })
          .catch(error => {
            console.log("login failure");
            console.log(error);
          });

        // <NavLink to=data ></NavLink>
    }

    return (
<div class="container">
    <header>
    <a href="/" class="back-button" >&larr;</a>
      <h1>
          PDS
      </h1>
    </header>
    <h1 class="text-center">LOGIN</h1>
    <form class="registration-form" onSubmit={handleLogin}>
      
		<label htmlFor="role">
			<span class="label-text">Your role:</span>
			<select id="role" className="input" value={role} onChange={handleVisibility}>
				<option value="">Select role</option>
				<option value="Farmer">Farmer</option>
				<option value="Miller">Miller</option>
				<option value="Fci">FCI</option>
				<option value="Fps">FPS</option>
			  </select>
		</label>
        
		<div className={isVisible ?'undefined':'hidden'}>
			<label htmlFor="aadhar">
				<span class="label-text">Aadhar Number:</span>
				<input type="text" name="aadhar" placeholder="Enter Aadhar number"/>
			</label>
			
		  </div>
		  <label htmlFor="pwd">
			<span class="label-text">Password</span>
			<input type="password" name="pwd" placeholder="Enter password"/>
		  </label>
		  <div class="text-center">
			<button class="submit" type="submit" value="Login">LOGIN</button>
      <br/>
      <br/>
			<button class="submit" ><NavLink to="/Signup" className="nav-link">Dont have an account?</NavLink></button>
		  </div>
		  </form>
		</div>
         
      );      
}

export default Login;