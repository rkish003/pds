import React, { useEffect, useState } from "react";
import axios from "axios";
import './css/styles1.css';

const FarmerComponent = () => {
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [grains, setGrains] = useState(0);
  const [ready, setReady] =useState(0);
  useEffect(() => {
    const loggedInName = localStorage.getItem("name");
    const loggedInRole = localStorage.getItem("role");
    const loggedInAadhar = localStorage.getItem("aadhar");
    const loggedInLocation = localStorage.getItem("location");

    if (loggedInName) {
      setName(loggedInName);
      setLocation(loggedInLocation);
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('http://localhost:3001/add-farmer', {
      name: name,
      location: location,
      grains: grains,
      ready: 0
    })
  }
  const handleReadyToSell = () => {
    axios.put('http://localhost:3001/farmer-ready' , {
      name: name,
      location: location,
      grains: grains,
      ready: 0
    })
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.error(error);
    });
  };
  const handleNotReadyToSell = () => {
    axios.put('http://localhost:3001/farmer-not-ready' ,{
      name: name,
      location: location,
      grains: grains,
      ready: 0
    })
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.error(error);
    });
  };

  const handleShowGrains = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-grains-farmer', {
        params: {
          name: name,
          location: location,
          grains: grains,
          ready: 0
        }
      });
      const farmerGrains = response.data.grains;
      console.log(farmerGrains);
      setGrains(farmerGrains);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    
    <div>
      

    <div class="container">
    <a href="/Login" class="back-button" >&larr;</a>
    <header>
    <h1>
          FARMER
      </h1>
    </header>
    <h1 class="text-center">WELCOME {name}</h1>
    <form class="registration-form"  onSubmit={handleSubmit}>
      <label>
        <span class="label-text">Grains</span> 
        <input type="text" value={grains}
            onChange={(e) => setGrains(e.target.value)}
            required />
      </label>
      
      
      <div class="text-center">
        <button class="submit" name="register"> SUBMIT <span class="glyphicon glyphicon-upload"></span></button>
        
       <br/>
       <br/>
        <button onClick={handleReadyToSell} class="submit" name="register"> Ready to Sell <span class="glyphicon glyphicon-chevron-down"></span></button>
        <button onClick={handleShowGrains} class="submit" name="register"> Show Grain <span class="glyphicon glyphicon-shopping-cart"></span></button>
        <button  onClick={handleNotReadyToSell}class="submit" name="register"> Remove from listing<span class="glyphicon glyphicon-trash"></span></button>
        <p>Grains: {grains}</p>
      </div>
      <br/>
      
    </form>
  </div>
  </div>
);
};

export default FarmerComponent;