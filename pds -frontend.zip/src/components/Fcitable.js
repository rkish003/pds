import React, { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
const FcitableComponent = () => {
    const [millers, setMillers] = useState([]);

const fetchMillers = async () => {
    try {
        const response = await axios.get('http://localhost:3001/show-millers');
        setMillers(response.data);
    } catch (error) {
        console.log(error);
    }
};

useEffect(() => {
    fetchMillers();
  }, []);

  return(

    <div>
      <title>MillerData</title>
     
      {/* <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/> */}
    <body>
      <nav class="navbar navbar-light" >
      <a href="/Fci" class="back-button" >&larr;</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-arrow-left" ></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            
            <button class="" type="button"></button>
          </div>
      </nav>
      
      <table class="table table-dark">
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Location</th>
            <th scope="col">Grains</th>
          </tr>
        </thead>
        <tbody>
          {millers.map((miller) => (
            <tr key={miller._id}>
              <td>{miller.name}</td>
              <td>{miller.location}</td>
              <td>{miller.grains}</td>
            </tr>
          ))}
        </tbody>
      </table>
    
      {/* <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script> */}
    </body>
    </div>
    )
    };
    
    export default FcitableComponent;