import React, { useState, useEffect } from 'react';
import { NavLink } from "react-router-dom";
import axios from "axios";
import "./css/styles1.css";
function Signup() {
    const [role,setRole] = useState("");
    const [isVisible,setIsVisible] = useState(false);
    // const [sname,setSName] = useState("");
    // const [srole,setSRole] = useState("");
    // const [spassword,setSPassword] = useState("");
    // const [saadhar,setSAadhar] = useState("");
    // const [slocation,setSLocation] = useState("");

    const handleSignup = (e) => {
        e.preventDefault();
        console.log("SDfs");
        console.log("target: " + e.target.role.value);
        var obj;
        if(e.target.role.value === "Fci") {
          // setSName("Fci");
          // setSRole(e.target.role.value);
          // setSPassword(e.target.pwd.value);
          const sname = "Fci";
          const srole = e.target.role.value;
          const spassword = e.target.pwd.value;
          const saadhar = "0000000000";
          const slocation = "Delhi";
          const sgrains = 0;
          const sready = 0;
          console.log({ sname, srole, spassword ,saadhar , slocation , sgrains , sready });
          axios.post('http://localhost:3001/signup',  {sname, srole, spassword  , saadhar, slocation , sgrains , sready} )
          .then(response => {
            console.log(response);
            window.location.replace('/Login');
          })
          .catch(error => {
            console.log(error);
          });
            // obj = {
            //     role:e.target.role.value,
            //     name:"Fci",
            //     password:e.target.pwd.value
            // }

        }
        else {
          const sname = e.target.name.value;
          const srole = e.target.role.value;
          const spassword = e.target.pwd.value;
          const saadhar = e.target.aadhar.value;
          const slocation = e.target.location.value;
          const sgrains = 0;
          const sready = 0;
          console.log({ sname, srole, spassword ,saadhar , slocation , sgrains , sready });
          axios.post('http://localhost:3001/signup',  {sname, srole, spassword  , saadhar, slocation , sgrains , sready} )
          .then(response => {
            window.location.replace('/Login');
            console.log(response);
          })
          .catch(error => {
            console.log(error);
          });
        }
        
      };
    
    function handleVisibility(e) {
        setRole(e.target.value);
        console.log(role);
        var currRole = e.target.value;
        if( currRole === "Fci" || currRole === "") {
          setIsVisible(false);
        }
        else {
          setIsVisible(true);
        }
        // <NavLink to=data ></NavLink>
    }

    return (
<div class="container">
    <header>
    <a href="/" class="back-button" >&larr;</a>
      <h1>
          PDS
      </h1>
    </header>
    <h1 class="text-center">SIGNUP</h1>
    <form class="registration-form" onSubmit={handleSignup}>
      
		<label htmlFor="role">
			<span class="label-text">Your role:</span>
			<select id="role" className="input" value={role} onChange={handleVisibility}>
				<option value="">Select role</option>
				<option value="Farmer">Farmer</option>
				<option value="Miller">Miller</option>
				<option value="Fci">FCI</option>
				<option value="Fps">FPS</option>
			  </select>
		</label>
        
		<div className={isVisible ?'undefined':'hidden'}>
    <label htmlFor="name">
				<span class="label-text">Name:</span>
				<input type="text" name="name" placeholder="Enter name"/>
			</label>
			<label htmlFor="aadhar">
				<span class="label-text">Aadhar Number:</span>
				<input type="text" name="aadhar" placeholder="Enter Aadhar number"/>
			</label>
			<label htmlFor="location">
				<span class="label-text">Location:</span>
				<input type="text" name="location" placeholder="Enter Location"/>
			</label>
		  </div>
		  <label htmlFor="pwd">
			<span class="label-text">Password</span>
			<input type="password" name="pwd" placeholder="Enter password"/>
		  </label>
		  <div class="text-center">
			<button class="submit" type="submit" value="Login">SIGNUP</button>
      <br/>
      <br/>
      <button class="submit" ><NavLink to="/Login" className="nav-link">Already have an account?</NavLink></button>
		  </div>
		  </form>
		</div>
      );      
}
export default Signup;