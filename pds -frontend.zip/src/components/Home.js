import React, { useEffect, useState } from "react";
import "./css/styles1.css";
import axios from "axios";
import { NavLink } from "react-router-dom";
function Home() {
    return ( 
        <div class="container">
        <header>
            <h1>HOME</h1>
          <h3>
            <a href="/Login">
              LOGIN
            </a>
            <br/>
            <br/>
            <a href="/Signup">
                SIGNUP
              </a>
          </h3>
        </header>
        
       
      </div>
     );
}

export default Home;