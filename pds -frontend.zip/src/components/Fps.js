import React, { useState, useEffect } from "react";
import axios from "axios";
import './css/styles1.css';

const FpsComponent = () => {
  const [name, setName] = useState("");
  const [grains, setGrains] = useState(0);

  useEffect(() => {
    const loggedInName = localStorage.getItem("name");
    const loggedInRole = localStorage.getItem("role");
    const loggedInAadhar = localStorage.getItem("aadhar");
    const loggedInLocation = localStorage.getItem("location");

    if (loggedInName) {
      setName(loggedInName);
    }
  }, []);



  const handleDeductGrains = (e) => {
    e.preventDefault();

    axios.post('http://localhost:3001/deduct-grains-fci', { grains })
      .then(response => {
        console.log(response);
      })
      .catch(error => {
        console.log(error);
      });

    setName("");
    setGrains("");
  };
  
  const handleShowGrains = async () => {
    try {
      const response = await axios.get('http://localhost:3001/show-grains-fps' , {
        params: {
          name: name
        }
      });
      const fpsGrains = response.data.grains;
      setGrains(fpsGrains);
    } catch (error) {
      console.error(error);
    }
  };

  const handleReadyToRequest = () => {
    axios.put('http://localhost:3001/fps-request', {name : name})
    .then(response => {
      console.log(response.data);
    })
    .catch(error => {
      console.error(error);
    });
  };

  return (
    <div>
    <div class="container">
    <a href="/Login" class="back-button" >&larr;</a>
    <header>
      <h1>
      <h1>Fps Component</h1>
      </h1>
      <h2>Welcome {name}</h2>
    </header>
    <br/><br/>
         <div class="text-center">
        <button class="fps-button" onClick={handleShowGrains}> SHOW GRAINS </button>
        <div class="text-center">
        <p>Grains: {grains}</p>
      </div>
      </div>
      <br/>
      <div class="text-center">
        <button class="fps-button" name="register" onClick={handleReadyToRequest}> REQUEST FROM FCI</button>
        
      </div>
      <br/>
     
      
  </div>
  </div>
  );
};

export default FpsComponent;